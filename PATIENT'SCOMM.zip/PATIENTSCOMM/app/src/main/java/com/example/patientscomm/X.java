package com.example.patientscomm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class X extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_x);
    }
}