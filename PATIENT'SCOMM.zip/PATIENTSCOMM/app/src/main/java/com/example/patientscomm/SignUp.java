package com.example.patientscomm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class SignUp extends AppCompatActivity {
    TextView username;
    TextView email;
    TextView password;
    TextView passwordRepeat;
    ListView disease;
    ListView doctor;
    ListView hospital;
    Button signUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        username=findViewById(R.id.signUpUsernameText);
        email=findViewById(R.id.signUpEmailText);
        password=findViewById(R.id.signUpPassword);
        passwordRepeat=findViewById(R.id.signUpPasswordRepeat);
        disease=findViewById(R.id.signUpDiseaseList);
        doctor=findViewById(R.id.signUpDoctorList);
        hospital=findViewById(R.id.signUpHospitalList);
        signUp=findViewById(R.id.signUpsignUpButton);
    }
}